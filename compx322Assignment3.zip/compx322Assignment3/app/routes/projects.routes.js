module.exports = app => {
  const projects = require("../controllers/projects.controller");

  // Create new project
  app.post("/projects", projects.create);

  // Get list of all projects
  app.get("/projects", projects.findAll);

  // Get project by Project ID
  app.get("/projects/:id", projects.findOne);

  // Get project by Project Name
  app.get("/projects", projects.findByName);

  // Update project information by Project ID
  app.put("/projects/:id", projects.update);

  // Delete project by Project ID
  app.delete("/projects/:id", projects.delete);

  // Delete all projects from the database
  app.delete("/projects", projects.deleteAll);
}