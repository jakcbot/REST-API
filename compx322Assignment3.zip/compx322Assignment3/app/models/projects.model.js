const db = require("./db");

const Project = function (project) {
  this.projectname = project.projectname;
  this.projectdesc = project.projectdesc;
  this.startdate = project.startdate;
  this.enddate = project.enddate;
};

// Create a new project
Project.create = (newProject, result) => {
  db.query("INSERT INTO projects SET ?", newProject, (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(err, null);
      return;
    }
    console.log("Created project:", { id: res.insertId, newProject });
    result(null, { id: res.insertId, newProject });
  });
};

// Retrieve all projects
Project.getAll = result => {
  db.query("SELECT * FROM projects", (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(null, err);
      return;
    }
    console.log("Projects:", res);
    result(null, res);
  });
};

// Retrieve a project by ID
Project.findById = (projectId, result) => {
  db.query("SELECT * FROM projects WHERE id = ?", projectId, (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(null, err);
      return;
    }
    if (res.length) {
      console.log("Found project:", res[0]);
      result(null, res[0]);
      return;
    }
    // Project not found
    result({ message: "Project not found" }, null);
  });
};

// Retrieve a project by project name
Project.findByName = (projectName, result) => {
  db.query("SELECT * FROM projects WHERE projectname = ?", projectName, (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(null, err);
      return;
    }
    if (res.length) {
      console.log("Found project:", res[0]);
      result(null, res[0]);
      return;
    }
    // Project not found
    result({ message: "Project not found" }, null);
  });
};

// Update a project by ID
Project.updateById = (id, project, result) => {
  db.query(
    "UPDATE projects SET projectname = ?, projectdesc = ?, startdate = ?, enddate = ? WHERE id = ?",
    [project.projectname, project.projectdesc, project.startdate, project.enddate, id],
    (err, res) => {
      if (err) {
        console.log("Error:", err);
        result(null, err);
        return;
      }
      if (res.affectedRows == 0) {
        // Project not found
        result({ message: "Project not found" }, null);
        return;
      }
      console.log("Updated project:", { id: id, project });
      result(null, { id: id, project });
    }
  );
};

// Delete a project by ID
Project.deleteById = (id, result) => {
  db.query("DELETE FROM projects WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(null, err);
      return;
    }
    if (res.affectedRows == 0) {
      // Project not found
      result({ message: "Project not found" }, null);
      return;
    }
    console.log("Deleted project with ID:", id);
    result(null, res);
  });
};

// Delete all projects
Project.deleteAll = result => {
  db.query("DELETE FROM projects", (err, res) => {
    if (err) {
      console.log("Error:", err);
      result(null, err);
      return;
    }
    console.log(
      "Deleted ${ res.affectedRows } projects"
    );
    result(null, res);
  });
};

module.exports = Project;