module.exports = {
  HOST: "learn-mysql.cms.waikato.ac.nz",
  USER: "jl537",
  PASSWORD: "my169283sql",
  DB: "jl537"
};