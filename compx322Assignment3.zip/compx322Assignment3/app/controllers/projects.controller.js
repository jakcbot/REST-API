// Import the Project model
const Project = require("../models/projects.model");

// Retrieve all projects from the database
exports.findAll = (req, res) => {
  Project.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving projects."
      });
    else res.send(data);
  });
};

// Create and save a new project
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // Create a new project
  const project = new Project({
    projectname: req.body.projectname,
    projectdesc: req.body.projectdesc,
    startdate: req.body.startdate,
    enddate: req.body.enddate
  });

  // Save the project in the database
  Project.create(project, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the project."
      });
    else res.send(data);
  });
};

// Retrieve a single project with the specified id
exports.findOne = (req, res) => {
  Project.findById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message:
            "Project not found with id " + req.params.id
        });
      } else {
        res.status(500).send({
          message: "Error retrieving project with id " + req.params.id
        });
      }
    } else res.send(data);
  });
};

// Retrieve a single project with the specified name
exports.findByName = (req, res) => {
  Project.findByName(req.query.name, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message:
            "Project not found with name " + req.query.name
        });
      } else {
        res.status(500).send({
          message: "Error retrieving project with name " + req.query.name
        });
      }
    } else res.send(data);
  });
};

// Update a project identified by the projectId in the request
exports.update = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  Project.updateById(
    req.params.id,
    new Project(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message:
              "Project not found with id " + req.params.id
          });
        } else {
          res.status(500).send({
            message: "Error updating project with id " + req.params.id
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a project with the specified projectId in the request
exports.delete = (req, res) => {
  Project.deleteById(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: "Project not found with id " + req.params.id
        });
      } else {
        res.status(500).send({
          message: "Could not delete project with id " + req.params.id
        });
      }
    } else res.send({ message: "Project deleted successfully!" });
  });
};

// Delete all projects from the database
exports.deleteAll = (req, res) => {
  Project.deleteAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while deleting all projects."
      });
    else res.send({ message: "All projects deleted successfully!" });
  });
};